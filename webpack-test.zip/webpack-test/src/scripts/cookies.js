'use strict';

console.log('Cookies here');
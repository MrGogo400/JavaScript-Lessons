'use strict';

console.log('Greetings from contact form!');
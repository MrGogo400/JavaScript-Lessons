'use strict';

import style from "../assets/styles/global.scss";

require ('./cookies.js');
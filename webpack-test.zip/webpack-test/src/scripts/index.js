'use strict';

const logValue = 'Welcome to our website';
console.log(logValue);

const sum = (a, b) => a + b;

const mySum = sum(3, 4)

console.log('mySum', mySum);